package modelo;

public abstract class Producto {

    private String cod;
    private String nom;
    private double cost;
    private int cant;

    public Producto(String cod, String nom, double cost, int cant) {
        this.cod = cod;
        this.nom = nom;
        this.cost = cost;
        this.cant = cant;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public int getCant() {
        return cant;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    public abstract double precioVenta();

    public double costoTotal() {
        return cost * cant;
    }

    public boolean porVencer() {
        return false;
    }

    public boolean vencido() {
        return false;
    }

    public String mostrar() {
        double prec = Math.round(precioVenta() * 100) / 100.0;
        return cod + " | " + nom + " | Cant: " + cant + " | Costo: $" + cost + " | Precio: $" + prec;
    }
}
