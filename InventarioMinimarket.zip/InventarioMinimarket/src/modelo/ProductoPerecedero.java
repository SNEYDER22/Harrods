package modelo;

public class ProductoPerecedero extends Producto {

    private int dias;

    public ProductoPerecedero(String cod, String nom, double cost, int cant, int dias) {
        super(cod, nom, cost, cant);
        this.dias = dias;
    }

    public int getDias() {
        return dias;
    }

    public void setDias(int dias) {
        this.dias = dias;
    }

    @Override
    public double precioVenta() {
        double prec = getCost() * 1.30;
        if (dias <= 5) {
            prec = prec * 0.80;
        }
        return prec;
    }

    @Override
    public boolean porVencer() {
        return dias <= 5;
    }

    @Override
    public boolean vencido() {
        return dias < 0;
    }

    @Override
    public String mostrar() {
        return "[Perecedero] " + super.mostrar() + " | Vence en: " + dias + " dias";
    }
}
