package modelo;

public class ProductoNoPerecedero extends Producto {

    private double marg;

    public ProductoNoPerecedero(String cod, String nom, double cost, int cant, double marg) {
        super(cod, nom, cost, cant);
        this.marg = marg;
    }

    public double getMarg() {
        return marg;
    }

    public void setMarg(double marg) {
        this.marg = marg;
    }

    @Override
    public double precioVenta() {
        return getCost() + getCost() * marg / 100;
    }

    @Override
    public String mostrar() {
        return "[No perecedero] " + super.mostrar() + " | Ganancia: " + marg + "%";
    }
}
