package negocio;

import java.util.ArrayList;
import modelo.Producto;

public class Inventario {

    private ArrayList<Producto> lis;
    private int cap;
    private double pres;
    private double vent;

    public Inventario(int cap, double pres) {
        this.lis = new ArrayList<Producto>();
        this.cap = cap;
        this.pres = pres;
        this.vent = 0;
    }

    public int getCap() {
        return cap;
    }

    public double getPres() {
        return pres;
    }

    public double getVent() {
        return vent;
    }

    public int totalUnid() {
        int tot = 0;
        for (int i = 0; i < lis.size(); i++) {
            tot = tot + lis.get(i).getCant();
        }
        return tot;
    }

    public double valorTotal() {
        double tot = 0;
        for (int i = 0; i < lis.size(); i++) {
            tot = tot + lis.get(i).costoTotal();
        }
        return tot;
    }

    public Producto buscar(String cod) {
        for (int i = 0; i < lis.size(); i++) {
            if (lis.get(i).getCod().equals(cod)) {
                return lis.get(i);
            }
        }
        return null;
    }

    public String agregar(Producto pro) {
        if (buscar(pro.getCod()) != null) {
            return "Error: ya existe un producto con ese codigo";
        }
        if (pro.getCost() <= 0) {
            return "Error: el costo debe ser mayor a 0";
        }
        if (pro.getCant() <= 0) {
            return "Error: la cantidad debe ser mayor a 0";
        }
        if (pro.vencido()) {
            return "Error: no se puede registrar un producto vencido";
        }
        if (totalUnid() + pro.getCant() > cap) {
            return "Error: no hay espacio suficiente en bodega";
        }
        if (pro.costoTotal() > pres) {
            return "Error: no alcanza el presupuesto";
        }
        lis.add(pro);
        pres = pres - pro.costoTotal();
        return "Producto agregado correctamente";
    }

    public String vender(String cod, int unid) {
        Producto pro = buscar(cod);
        if (pro == null) {
            return "Error: producto no encontrado";
        }
        if (unid <= 0) {
            return "Error: las unidades deben ser mayores a 0";
        }
        if (unid > pro.getCant()) {
            return "Error: solo hay " + pro.getCant() + " unidades disponibles";
        }
        pro.setCant(pro.getCant() - unid);
        vent = vent + pro.precioVenta() * unid;
        return "Venta realizada correctamente";
    }

    public boolean eliminar(String cod) {
        Producto pro = buscar(cod);
        if (pro == null) {
            return false;
        }
        lis.remove(pro);
        return true;
    }

    public void mostrarTodo() {
        if (lis.size() == 0) {
            System.out.println("Inventario vacio");
        }
        for (int i = 0; i < lis.size(); i++) {
            System.out.println(lis.get(i).mostrar());
        }
    }

    public void mostrarPorVencer() {
        boolean hay = false;
        for (int i = 0; i < lis.size(); i++) {
            if (lis.get(i).porVencer()) {
                System.out.println(lis.get(i).mostrar());
                hay = true;
            }
        }
        if (!hay) {
            System.out.println("No hay productos por vencer");
        }
    }
}
