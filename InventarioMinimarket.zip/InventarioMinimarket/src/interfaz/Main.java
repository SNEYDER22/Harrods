package interfaz;

import java.util.Scanner;
import modelo.Producto;
import modelo.ProductoNoPerecedero;
import modelo.ProductoPerecedero;
import negocio.Inventario;

public class Main {

    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        Inventario inv = new Inventario(500, 2000);

        inv.agregar(new ProductoPerecedero("P01", "Leche", 0.90, 48, 3));
        inv.agregar(new ProductoPerecedero("P02", "Pan", 0.15, 100, 2));
        inv.agregar(new ProductoPerecedero("P03", "Yogurt", 1.10, 30, 12));
        inv.agregar(new ProductoNoPerecedero("N01", "Arroz", 1.05, 60, 25));
        inv.agregar(new ProductoNoPerecedero("N02", "Detergente", 2.50, 20, 35));

        int opc = -1;
        while (opc != 0) {
            System.out.println();
            System.out.println("MINIMARKET HARRODS");
            System.out.println("1. Agregar producto perecedero");
            System.out.println("2. Agregar producto no perecedero");
            System.out.println("3. Ver inventario");
            System.out.println("4. Buscar producto");
            System.out.println("5. Vender producto");
            System.out.println("6. Eliminar producto");
            System.out.println("7. Ver productos por vencer");
            System.out.println("8. Resumen");
            System.out.println("0. Salir");
            System.out.print("Opcion: ");
            String top = ent.nextLine();
            try {
                opc = Integer.parseInt(top);
            } catch (NumberFormatException e) {
                opc = -1;
            }

            if (opc == 1 || opc == 2) {
                System.out.print("Codigo: ");
                String cod = ent.nextLine();
                System.out.print("Nombre: ");
                String nom = ent.nextLine();
                System.out.print("Costo unitario: ");
                String tcos = ent.nextLine();
                System.out.print("Cantidad: ");
                String tcan = ent.nextLine();
                if (opc == 1) {
                    System.out.print("Dias para vencer: ");
                } else {
                    System.out.print("Porcentaje de ganancia: ");
                }
                String tdat = ent.nextLine();

                if (cod.isEmpty()) {
                    System.out.println("Error: el codigo es obligatorio");
                } else if (nom.isEmpty()) {
                    System.out.println("Error: el nombre es obligatorio");
                } else if (tcos.isEmpty()) {
                    System.out.println("Error: el costo es obligatorio");
                } else if (tcan.isEmpty()) {
                    System.out.println("Error: la cantidad es obligatoria");
                } else if (tdat.isEmpty() && opc == 1) {
                    System.out.println("Error: los dias para vencer son obligatorios");
                } else if (tdat.isEmpty() && opc == 2) {
                    System.out.println("Error: el porcentaje de ganancia es obligatorio");
                } else {
                    try {
                        double cost = Double.parseDouble(tcos.replace(",", "."));
                        int cant = Integer.parseInt(tcan);
                        Producto pro;
                        if (opc == 1) {
                            int dias = Integer.parseInt(tdat);
                            pro = new ProductoPerecedero(cod, nom, cost, cant, dias);
                        } else {
                            double marg = Double.parseDouble(tdat.replace(",", "."));
                            pro = new ProductoNoPerecedero(cod, nom, cost, cant, marg);
                        }
                        System.out.println(inv.agregar(pro));
                    } catch (NumberFormatException e) {
                        System.out.println("Error: costo, cantidad, dias y ganancia deben ser numeros");
                    }
                }
            } else if (opc == 3) {
                inv.mostrarTodo();
            } else if (opc == 4) {
                System.out.print("Codigo: ");
                String cod = ent.nextLine();
                Producto pro = inv.buscar(cod);
                if (pro == null) {
                    System.out.println("Error: producto no encontrado");
                } else {
                    System.out.println(pro.mostrar());
                }
            } else if (opc == 5) {
                System.out.print("Codigo: ");
                String cod = ent.nextLine();
                System.out.print("Unidades: ");
                String tuni = ent.nextLine();
                if (tuni.isEmpty()) {
                    System.out.println("Error: las unidades son obligatorias");
                } else {
                    try {
                        int unid = Integer.parseInt(tuni);
                        System.out.println(inv.vender(cod, unid));
                    } catch (NumberFormatException e) {
                        System.out.println("Error: las unidades deben ser un numero");
                    }
                }
            } else if (opc == 6) {
                System.out.print("Codigo: ");
                String cod = ent.nextLine();
                if (inv.eliminar(cod)) {
                    System.out.println("Producto eliminado correctamente");
                } else {
                    System.out.println("Error: producto no encontrado");
                }
            } else if (opc == 7) {
                inv.mostrarPorVencer();
            } else if (opc == 8) {
                double val = Math.round(inv.valorTotal() * 100) / 100.0;
                double pres = Math.round(inv.getPres() * 100) / 100.0;
                double vent = Math.round(inv.getVent() * 100) / 100.0;
                System.out.println("Unidades en bodega: " + inv.totalUnid() + " de " + inv.getCap());
                System.out.println("Espacio libre: " + (inv.getCap() - inv.totalUnid()));
                System.out.println("Valor del inventario: $" + val);
                System.out.println("Presupuesto restante: $" + pres);
                System.out.println("Total vendido: $" + vent);
            } else if (opc == 0) {
                System.out.println("Fin del programa");
            } else {
                System.out.println("Error: opcion no valida");
            }
        }
        ent.close();
    }
}
